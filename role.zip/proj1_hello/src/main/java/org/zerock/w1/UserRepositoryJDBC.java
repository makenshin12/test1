package org.zerock.w1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserRepositoryJDBC implements UserRepository{
	
    
    public UserRepositoryJDBC() {
    	
	}

	@Override
    public User findByUserId(String userId) {
        User user = null;
        EmpDAO empDAO = new EmpDAO();
        Connection con = empDAO.getConn();
        String sql = "SELECT * FROM users WHERE userId = ?";
        System.out.println(sql);
        try {
        	PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setString(1, userId);
            System.out.println(userId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                user = new User();
                user.setUserId(rs.getString("userId"));
                user.setPassword(rs.getString("password"));
                System.out.println(rs.getString("password"));
                user.setName(rs.getString("name"));
                String roleStr = rs.getString("role");
                Role role = Role.fromString(roleStr);
                user.setRole(role);
                System.out.println(role);
                
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return user;
    }
}

