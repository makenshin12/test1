package org.zerock.w1;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	
	private UserRepository userRepository;
	public void init() {
        userRepository = new UserRepositoryJDBC();
    }
	
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // 폼에서 전송된 아이디와 비밀번호를 받아옴
        String userId = request.getParameter("userid");
        String password = request.getParameter("password");
        System.out.println(password);

        // 데이터베이스에서 사용자 정보 조회 (만들예정)
        User user = userRepository.findByUserId(userId);

        if (user != null && user.getPassword().equals(password)) {
            // 로그인 성공: 사용자 정보와 권한을 세션에 저장
            HttpSession session = request.getSession();
            session.setAttribute("user", user.getUserId());
            session.setAttribute("role", user.getRole().name()); // 권한 정보 저장
            System.out.println(user.getRole());

            // 메인 페이지 또는 권한에 따른 페이지로 리다이렉트
            if (user.getRole() == Role.ADMIN) {
                response.sendRedirect("main.jsp"); 
            } else {
                response.sendRedirect("main.jsp");
            }
        } else {
            request.setAttribute("errorMessage", "아이디 혹은 비밀번호가 틀렸습니다.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}
