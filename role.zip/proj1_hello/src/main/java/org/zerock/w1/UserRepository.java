package org.zerock.w1;

public interface UserRepository {
    User findByUserId(String userId);
}
