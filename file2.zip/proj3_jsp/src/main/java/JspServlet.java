

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class JspServlet
 */
@WebServlet("/jsp")
public class JspServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id"); // 브라우저를 통해 받음
//		response.sendRedirect("param.jsp?id="+id);	
//		request.getRequestDispatcher("param.jsp?id="+id).forward(request,response);
		// 어차피 request를 전달하고 jsp는 거기서 id값을 꺼낼 수 있다
		request.setAttribute("id2", id);
		
		List<String> list = new ArrayList<String>();
		list.add("김");
		list.add("태");
		list.add("원");
		request.setAttribute("list", list);
		
		request.getRequestDispatcher("param.jsp").forward(request,response);
	}

}
