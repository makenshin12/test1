package com.pc.emp.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.pc.emp.dao.EmpRepositoryJDBC;
import com.pc.emp.dto.Account;
import com.pc.emp.dto.JsonResponse;

@WebServlet("/account")
public class AccountServlet extends HttpServlet {
	private Gson gson = new Gson();
	private EmpRepositoryJDBC acctRepo = new EmpRepositoryJDBC();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action"); // 액션값 가져오기

		if ("list".equals(action)) {
			// 계정 리스트 메서드 호출
			listAccounts(response);
		} else {
			forwardAcctMgmt(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");

		if ("updateRole".equals(action)) {
			updateAccountRole(request, response);
		} else {
			// 기존 doGet 메서드 호출로 대체 가능한 다른 액션 처리
			doGet(request, response);
		}
	}

	// 계정 리스트
	private void listAccounts(HttpServletResponse response) throws IOException {
		List<Account> acctList = acctRepo.getAccountList();
		String json = gson.toJson(acctList);
		writeResponse(response, json);
	}

	// 권한 수정
	private void updateAccountRole(HttpServletRequest request, HttpServletResponse response) throws IOException {
		int empno = Integer.parseInt(request.getParameter("empno"));
		String newRole = request.getParameter("newRole");
		boolean updateSuccess = acctRepo.updateRole(empno, newRole);
		PrintWriter out = response.getWriter();

		if (updateSuccess) {
			writeJsonResponse(out, true, "권한이 성공적으로 변경되었습니다.");
		} else {
			writeJsonResponse(out, false, "권한 변경에 실패 했습니다.");
		}
	}

	// 포워딩
	private void forwardAcctMgmt(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getRequestDispatcher("/WEB-INF/acctmgmt.jsp").forward(request, response);
	}

	// json 방식의 응답
	private void writeJsonResponse(PrintWriter out, boolean success, String message) {
		Gson gson = new Gson();
		JsonResponse response = new JsonResponse(success, message);
		out.println(gson.toJson(response));
	}

	private void writeResponse(HttpServletResponse response, String json) throws IOException {
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().print(json);
	}

}
