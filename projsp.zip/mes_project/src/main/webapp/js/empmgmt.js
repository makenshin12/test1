const hover = document.querySelectorAll('a.hover');
const menuBar = document.querySelector('.menu-bar');
const nav = document.querySelector('nav');
const wrap = document.querySelector('.wrap');

// 모바일 스크립트 코드
const hamburgerMenu = document.querySelector('.hamburger-menu');
const myPage = document.querySelector('#myPage');

hamburgerMenu.addEventListener('click', function() {
	nav.classList.toggle('active');

	if (nav.classList.contains('active')) {
		nav.prepend(myPage);
		myPage.style.display = 'flex';
		myPage.style.padding = '5px 0';
		myPage.style.backgroundColor = '#dde';

		let sectionHeight = section.offsetHeight;
		nav.style.height = `${sectionHeight}px`;
	} else {
		workerTitle.appendChild(myPage);
		myPage.style.display = '';
		nav.style.height = '';
	}
});
// 미디어테그, 네비게이션바 조작
const section = document.querySelector('section');

hover.forEach(link => {
	link.addEventListener("click", function(event) {
		event.preventDefault();
		if (nav.classList.contains('active') && window.matchMedia("(max-width: 430px)").matches) {
			nav.style.height = `${section.offsetHeight}px`
		}
	});
});

// 미디어테그 끝


let isHovered = false;

hover.forEach(button => {
	button.addEventListener('mouseover', () => {
		showMenuBar();
		isHovered = true;
	});
});

wrap.addEventListener("mouseleave", function() {
	if (!isHovered) {
		hideMenuBar();
	}
});

menuBar.addEventListener("mouseenter", function() {
	isHovered = true;
});

menuBar.addEventListener("mouseleave", function() {
	hideMenuBar();
});

section.addEventListener('click', function() {
	hideMenuBar();
})

function showMenuBar() {
	nav.classList.add('active');
}

function hideMenuBar() {
	nav.classList.remove('active');
}

hover.forEach(link => {
	link.addEventListener("click", function(event) {
		let myPage = document.querySelector("#myPage");
		// let myPageName = document.querySelector("#workerName");
		// let myPageLogo = document.querySelector("#myPageLogo");
		let menuBar = document.querySelector(".menu-bar");
		let mainPage = document.querySelector(".wrap");
		let companyLogo = document.querySelector("#workerLogo");

		let ulLi = document.querySelectorAll(".menu-bar-content ul li");


		event.preventDefault();
		if (nav.classList.contains('active') && window.matchMedia("(max-width: 430px)").matches) {
			nav.style.height = `${section.offsetHeight}px`

			for (let i = 0; i < ulLi.length; i++) {
				ulLi[i].style.padding = '7px';

			}
			menuBar.prepend(myPage);
		}
	});
});

// 팝업 2에 대한 클릭이벤트
document.querySelector(".add_button").addEventListener("click", function() {
	let EAI2 = document.querySelector(".popup2");
	let modal_overlay = document.querySelector(".modal-overlay");
	modal_overlay.style.display = "flex";
	EAI2.style.display = "inline-block";
})

// 직원추가 취소
document.querySelector(".cancel2").addEventListener("click", function() {

	//창 닫기
	document.querySelector(".error1").innerHTML = "";
	document.querySelector(".error2").innerHTML = "";
	document.querySelector(".error3").innerHTML = "";
	document.querySelector(".error4").innerHTML = "";
	document.querySelector(".error5").innerHTML = "";
	let EAI2 = document.querySelector(".popup2");
	EAI2.style.display = "none";
	let modal_overlay = document.querySelector(".modal-overlay");
	modal_overlay.style.display = "none";
});

// 숫자 체크
function isNumeric(value) {
	return /^-?\d+$/.test(value);
}

function validateForm() {
	var empNumber = document.getElementById("empNumber").value.trim();
	var ename = document.getElementById("ename").value.trim();
	var hireDate = document.getElementById("hireDate").value.trim();
	var job = document.getElementById("job").value.trim();
	var sal = document.getElementById("sal").value.trim();

	// 입력값이 비어 있는지 확인
	if (empNumber == "") {
		displayErrorMessage(".error1", "직원 번호를 입력해주세요.");
		return false;
	} else if (!isNumeric(empNumber)) {
		displayErrorMessage(".error1", "숫자만 입력하세요.");
		return false;
	}

	if (ename == "") {
		displayErrorMessage(".error2", "성명을 입력해주세요.");
		return false;
	}

	if (hireDate == "") {
		displayErrorMessage(".error3", "채용 일자를 선택해주세요");
		return false;
	}

	if (job == "") {
		displayErrorMessage(".error4", "직책을 입력해주세요");
		return false;
	}

	if (sal == "") {
		displayErrorMessage(".error5", "연봉을 입력해주세요");
		return false;
	}

	// 모든 조건이 충족되면 유효한 입력이므로 true 반환
	return true;
}

function displayErrorMessage(selector, message) {
	let errorDiv = document.querySelector(selector);
	errorDiv.innerHTML = message;
	errorDiv.style.color = "red";

	// 3초 후에 오류 메시지를 지움
	setTimeout(function() {
		errorDiv.innerHTML = "";
	}, 3000);
}

// 직원추가
document.querySelector(".add_eaib").addEventListener("click", function() {

	if (validateForm()) {
		// 입력값이 유효할 경우 모달 창 닫기
		let EAI2 = document.querySelector(".popup2");
		EAI2.style.display = "none";
		let modal_overlay = document.querySelector(".modal-overlay");
		modal_overlay.style.display = "none";
	}
});


