package com.pc.emp.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.pc.emp.dto.EmpDTO;
import com.pc.emp.dto.Employee;
import com.pc.emp.dto.Role;

public class EmpRepositoryJDBC implements EmpRepository {

	public EmpRepositoryJDBC() {

	}

	@Override
	public Employee findByUserId(String userId) {
		Employee empolyee = null;
		EmpDAO empDAO = new EmpDAO();
		Connection con = empDAO.getConn();
		String sql = "SELECT * FROM users WHERE userId = ?";
		System.out.println(sql);
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, userId);
			System.out.println("userId: " + userId);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				empolyee = new Employee();
				empolyee.setUserId(rs.getString("userId"));
				empolyee.setPassword(rs.getString("password"));
				System.out.println("rs.getString(password): " + rs.getString("password"));
				empolyee.setName(rs.getString("name"));
				String roleStr = rs.getString("role");
				Role role = Role.fromString(roleStr);
				empolyee.setRole(role);
			}
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return empolyee;
	}

	@Override
	public List<EmpDTO> getEmpList(EmpDTO empDTO) {
		//DB 호출
		EmpDAO empDAO = new EmpDAO();
		Connection con = empDAO.getConn();
		List<EmpDTO> empList = new ArrayList<EmpDTO>();
		// sql문 작성
		String sql = "SELECT * FROM emp2 WHERE lower(ename) LIKE '%' || lower(?) || '%' ORDER BY ename ASC";
		System.out.println(sql);
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, empDTO.getEname());
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				EmpDTO employee = new EmpDTO();
				employee.setEmpno(rs.getInt("empno"));
				employee.setEname(rs.getString("ename"));
				employee.setHiredate(rs.getDate("hiredate"));
				employee.setJob(rs.getString("job"));
				employee.setSal(rs.getInt("sal"));
				empList.add(employee);
			}
			System.out.println(empList);

			rs.close();
			ps.close();
			con.close();
			

		} catch (Exception e) {
			e.printStackTrace();
		}
		return empList;
	}
	
	public boolean addEmp(EmpDTO emp) {
	    EmpDAO empDAO = new EmpDAO();
	    Connection con = empDAO.getConn();
	    // SQL INSERT 문을 작성합니다.
	    String sql = "INSERT INTO emp2 (empno, ename, hiredate, job, sal) VALUES (?, ?, ?, ?, ?)";
	    
	    try {
	        PreparedStatement ps = con.prepareStatement(sql);
	        ps.setInt(1, emp.getEmpno());
	        ps.setString(2, emp.getEname());
	        ps.setDate(3, new Date(emp.getHiredate().getTime())); // java.util.Date를 java.sql.Date로 변환
	        ps.setString(4, emp.getJob());
	        ps.setInt(5, emp.getSal());
	        
	        int result = ps.executeUpdate(); // SQL 실행
	        
	        ps.close();
	        con.close();
	        
	        return result > 0; // 삽입 성공 여부 반환 (성공하면 true, 실패하면 false)
	    } catch (SQLException e) {
	        e.printStackTrace();
	        return false; // 예외 발생 시 실패로 처리
	    } 
	    
	}
	
	public boolean isEmpNumberExist(int empNumber) {
		EmpDAO empDAO = new EmpDAO();
	    Connection con = empDAO.getConn();
	    String sql = "SELECT COUNT(empno) FROM emp2 WHERE empno = ?";
	    try {
	        PreparedStatement ps = con.prepareStatement(sql);
	        ps.setInt(1, empNumber);
	        ResultSet rs = ps.executeQuery();
	        if (rs.next()) {
	            int count = rs.getInt(1);
	            return count > 0;
	        }
	        rs.close();
	        ps.close();
	        con.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } 
	    return false;
	}
	
	
}
