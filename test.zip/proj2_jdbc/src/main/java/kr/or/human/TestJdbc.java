package kr.or.human;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.human.emp.dto.EmpDTO;

@WebServlet("/test")
public class TestJdbc extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		controller(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		controller(request, response);
	}

	protected void controller(HttpServletRequest request, HttpServletResponse response) {
		// 한글 깨짐 방지
		try {
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html; charset=utf-8;");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@112.148.46.134:51521:xe";
		String user = "scott4_1";
		String password = "tiger";

		try {

			// 드라이버 로딩
			// Class.forName : String 변수로 class 생성
			Class.forName(driver);
			System.out.println("Oracle 드라이버 로딩 성공");

			// DB 접속
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("Connection 생성 성공");
			String name = request.getParameter("name");
			// SQL 작성

			String query = "";
			query += " select";
			query += " *";
			query += " from";
			query += " emp2";
			query += " where lower(ename) like '%' || lower(?) || '%'";
			// select*fromemp
			System.out.println("query : " + query);

			// SQL 실행 준비
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, name);

			// SQL 실행, ResultSet으로 결과 확보
			ResultSet rs = ps.executeQuery();
			// select : executeQuery()
			// return : ResultSet
			// 그 외 : executeUpdate()
			// return : int(몇개의 row가 영향을 받았는지)

			// DB 값을 활용
			// ResultSet에는 모든 줄이 담겨져 있음
			// rs.next() : 다음줄이 있는지 여부
			// next() 실행 후에 ResultSet에는 다음줄이 담김
//			if( rs.next() ) {
			List<EmpDTO> employeeList = new ArrayList<>();
			while (rs.next()) {
				EmpDTO employee = new EmpDTO();
				employee.setEmpno(rs.getInt("empno"));
				employee.setEname(rs.getString("ename"));
				employee.setHiredate(rs.getDate("hiredate"));
				employee.setJob(rs.getString("job"));
				employee.setSal(rs.getInt("sal"));
				employeeList.add(employee);
			}
			System.out.println(employeeList);
			request.setAttribute("employees", employeeList);
	        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/employeeList.jsp");
	        dispatcher.forward(request, response);

			rs.close();
			ps.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
