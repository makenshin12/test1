package sec01.exam01;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class OutputExam {

	public static void main(String[] args) {
		String path = "C:\\temp";
		String fileName = "test.txt";

		OutputStream os = null;
		try {
			os = new FileOutputStream(path + "\\" + fileName);
			String data = "abc\n한글\n123";
			byte[] datas = data.getBytes();

			os.write(datas);
			os.flush();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (os != null) {
				try {
					os.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
