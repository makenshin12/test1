package sec01.exam01;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

public class InputExam {

	public static void main(String[] args) {
		String path = "C:\\temp";
		String fileName = "test.txt";
		String charset = "UTF-8";

		try (InputStreamReader isr = new InputStreamReader(new FileInputStream(path + "\\" + fileName), charset);
				BufferedReader br = new BufferedReader(isr)) {
			String line;
			while ((line = br.readLine()) != null) {
				System.out.println(line);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
