package com.pc.emp.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.List;
import java.sql.Date;

import com.pc.emp.dao.EmpRepositoryJDBC;
import com.pc.emp.dto.EmpDTO;

@WebServlet("/emp")
public class EmpServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");

		String empNumberStr = request.getParameter("empNumber");
		String ename = request.getParameter("ename");
		String hireDateStr = request.getParameter("hireDate");
		String job = request.getParameter("job");
		String salStr = request.getParameter("sal");

		if (empNumberStr == null || empNumberStr.trim().isEmpty() || ename == null || ename.trim().isEmpty()
				|| hireDateStr == null || hireDateStr.trim().isEmpty() || job == null || job.trim().isEmpty()
				|| salStr == null || salStr.trim().isEmpty()) {
			request.setAttribute("errorMessage", "잘못된 입력 입니다.");
			RequestDispatcher dispatcher = request.getRequestDispatcher("/emplist");
			dispatcher.forward(request, response);
			return;
		}

		try {
			int empNumber = Integer.parseInt(empNumberStr);
			int sal = Integer.parseInt(salStr);
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date parsedDate = dateFormat.parse(hireDateStr);
			Date hireDate = new Date(parsedDate.getTime());

			EmpDTO empDTO = new EmpDTO();
			empDTO.setEmpno(empNumber);
			empDTO.setEname(ename);
			empDTO.setJob(job);
			empDTO.setSal(sal);
			empDTO.setHiredate(hireDate);

			EmpRepositoryJDBC empRepo = new EmpRepositoryJDBC();
			
			if (empRepo.isEmpNumberExist(empNumber)) {
	            request.setAttribute("errorMessage", "직원 번호가 이미 존재합니다.");
	            RequestDispatcher dispatcher = request.getRequestDispatcher("/emplist");
	            dispatcher.forward(request, response);
	            return;
	        }
			
			boolean result = empRepo.addEmp(empDTO);

			if (result) {
				// 데이터가 성공적으로 추가되었다면, 사용자를 직원 목록 페이지로 리디렉션합니다.
				response.sendRedirect(request.getContextPath() + "/emplist");
			} else {
				response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "데이터 삽입 실패");
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "잘못된 요청 데이터");
		}
	}
}
