package com.pc.emp.view;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pc.emp.dao.EmpRepositoryJDBC;
import com.pc.emp.dto.EmpDTO;

/**
 * Servlet implementation class EmpView
 */
@WebServlet("/emplist")
public class EmpView extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		EmpRepositoryJDBC empRepo = new EmpRepositoryJDBC();
		EmpDTO empDTO = new EmpDTO(); // 필요한 경우 검색 조건을 설정할 수 있습니다.
		// 예를 들어, empDTO.setEname("Smith");

		List<EmpDTO> empList = empRepo.getEmpList(empDTO);
		
		request.setAttribute("empList", empList);
		request.getRequestDispatcher("/WEB-INF/empmgmt.jsp").forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    doGet(request, response);
	}
	

}
