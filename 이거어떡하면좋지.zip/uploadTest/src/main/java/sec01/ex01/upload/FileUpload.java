package sec01.ex01.upload;

import java.io.File;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

@WebServlet("/upload.do")
public class FileUpload extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String encoding = "utf-8";
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");
        request.setCharacterEncoding(encoding);

        String userId = null;
        String userName = null;
        String password = null;
        String email = null;
        String profilePic = null;

        try {
            File currentDirPath = new File("C:\\file_repo");
            DiskFileItemFactory factory = new DiskFileItemFactory();
            factory.setRepository(currentDirPath);
            factory.setSizeThreshold(1024 * 1024);

            ServletFileUpload upload = new ServletFileUpload(factory);
            upload.setFileSizeMax(1024 * 1024 * 100);

            List<FileItem> items = upload.parseRequest(request);

            for (FileItem item : items) {
                if (item.isFormField()) {
                    String fieldName = item.getFieldName();
                    switch (fieldName) {
                        case "userId":
                            userId = item.getString(encoding);
                            break;
                        case "userName":
                            userName = item.getString(encoding);
                            break;
                        case "password":
                            password = item.getString(encoding);
                            break;
                        case "email":
                        		email = item.getString(encoding);
                    }
                } else {
                    System.out.println("param:" + item.getFieldName());
                    System.out.println("file name:" + item.getName());
                    System.out.println("file size:" + item.getSize() + "Bytes");

                    if (item.getSize() > 0) {
                        int idx = item.getName().lastIndexOf("\\");
                        if (idx == -1) {
                            idx = item.getName().lastIndexOf("/");
                        }
                        String fileName = item.getName().substring(idx + 1);
                        long timestamp = System.currentTimeMillis();
                        profilePic = timestamp + "_" + fileName;
                        File uploadFile = new File(currentDirPath + "\\" + profilePic);
                        item.write(uploadFile);
                    }
                }
            }
            
            System.out.println("userId: "+userId);
            System.out.println("userName: "+userName);
            System.out.println("password: "+password);
            System.out.println("email: "+email);
            System.out.println("profilePic: "+profilePic);

            // DB에 저장할 수 있겠다
            if (userId != null && userName != null && password != null && profilePic != null) {
                User user = new User(userId, userName, password, email, profilePic);
                
                System.out.println("userId: " + user.getUserId());
                System.out.println("userName: " + user.getUserName());
                System.out.println("password: " + user.getPassword());
                System.out.println("email: " + user.getEmail());
                System.out.println("profilePic: " + user.getProfilePic());
                
                UserDAO userDAO = new UserDAO();
                userDAO.insertUser(user);
                response.getWriter().print("회원 가입 및 파일 업로드 성공!");
            } else {
                response.getWriter().print("필수 정보 누락으로 회원 가입 실패.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().print("업로드 중 오류 발생: " + e.getMessage());
        }
    }
}