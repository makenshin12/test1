package sec01.ex01.upload;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class UserDAO {

	private Connection con;

	private void connDB() {

		try {
			Context ctx = new InitialContext();
			DataSource dataFactory = (DataSource) ctx.lookup("java:/comp/env/jdbc/oracle");
			this.con = dataFactory.getConnection();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean insertUser(User user) {
		connDB(); // 데이터베이스 연결

		System.out.println("insertUser 시작");
		
		String sql = "INSERT INTO users (userId, userName, password, email, profilePic) VALUES (?, ?, ?, ?, ?)";
		PreparedStatement ps = null;
		boolean result = false;

		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, user.getUserId());
			ps.setString(2, user.getUserName());
			ps.setString(3, user.getPassword());
			ps.setString(4, user.getEmail());
			ps.setString(5, user.getProfilePic());

			System.out.println("SQL 실행 전"); // SQL 실행 전 로그
			int rowsInserted = ps.executeUpdate();

			if (rowsInserted > 0) {
				result = true;
			}
		} catch(Exception e) {
			e.printStackTrace();
			System.out.println("예외 발생: " + e.getMessage()); // 예외 발생시 로그
		} finally {
			if (con != null) {
				try {
					con.close();
					System.out.println("데이터베이스 연결 닫힘"); // 연결 닫힘 로그
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		System.out.println("insertUser 종료, 결과: " + result); // 종료 로그
		return result;
	}

}
