package sec01.ex02.download;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/download.do")
public class FileDownload extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String file_rep = "c:\\file_repo";
		String fileName = request.getParameter("fileName");
		System.out.println("fileName: "+fileName);
		
		System.out.println("폴더 구분자 1: "+System.getProperty("file.separator"));
		System.out.println("폴더 구분자 2: "+File.separator);
		
		// file full path
		String downFile = file_rep + File.separator + fileName;
		
		// file 클래스에 path 값 저장
		File f = new File(downFile);
		
		// 파일을 읽을 stream 을 열어서 준비
		FileInputStream in = new FileInputStream(f);
		
		// 브라우저는 캐시를 사용하지 않도록
		// 같은 파일은 두번 안받으려고 노력하기 때문
		response.setHeader("Cache-Control", "no-cache");
		response.addHeader("Content-disposition", "attachment; fileName="+ fileName);
		
		OutputStream os = response.getOutputStream();
		
		// 흐름에서 자바 메모리로 퍼 올릴 바가지의 크기
		byte[] buf = new byte[1024 * 1];  // 보통은 8KB정도로 쓴다
		
		
		while(true) {
			// in.read(buf) : buf만큼 stream에서 읽어서 jvm 메모리에 올림
			// 읽은 byte의 용량만큼 돌려준다 단, 더 읽을 내용이 없으면 -1 반환
			int count = in.read(buf);
			System.out.println("읽은 크기 count: "+count);
			// 더이상 읽을 내용이 없으면 while을 종료시킴
			if(count == -1) {
				break;
			}
			
			// 응답의 내보내는 흐름에 바가지의 내용을 보낸다
			// 0: 바가지의 처음 값부터
			// count : 읽은 만큼
			os.write(buf, 0, count);
		}
		in.close();
		os.close();		
	}	
		
}
