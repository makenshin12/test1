package org.zerock.w1;

import java.util.ArrayList;
import java.util.List;

public class BulletinBoard {
	private List<String> messages;

    public BulletinBoard() {
        messages = new ArrayList<>();
    }

    public void addMessage(String title, String message) {
        String formattedMessage = title + ": " + message;
        messages.add(formattedMessage);
    }

    public List<String> getMessages() {
        return messages;
    }
}
