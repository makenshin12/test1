package org.zerock.w1;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class BulletinBoardServlet
 */
@WebServlet("/board")
public class BulletinBoardServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String title = request.getParameter("title");
		String message = request.getParameter("message");

		BulletinBoard bulletinBoard = new BulletinBoard();
		bulletinBoard.addMessage(title, message);
		
		
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setAttribute("title", title);
		request.setAttribute("message", message);
		request.getRequestDispatcher("BoardResult.jsp").forward(request, response);
	}

}
