package org.zerock.w1;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	   @Override
	   protected void doPost(HttpServletRequest request, HttpServletResponse response)
	         throws ServletException, IOException {
	      // 폼에서 전송된 아이디와 비밀번호를 받아옴
	      String userId = request.getParameter("userid");
	      String password = request.getParameter("pass");

	      if ("admin".equals(userId) && "admin041".equals(password)) {
	         // 로그인 성공: 사용자 정보를 세션에 저장
	         HttpSession session = request.getSession();
	         session.setAttribute("user", userId);

	         // 메인 페이지로 리다이렉트
	         response.sendRedirect("main.jsp");
	      } else {
	         request.setAttribute("errorMessage", "아이디 혹은 비밀번호가 틀렸습니다.");
	         request.getRequestDispatcher("login.jsp").forward(request, response);
	      }
	   }
	}