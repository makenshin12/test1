package org.zerock.w1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ParamServlet
 */
@WebServlet("/param")
public class ParamServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// 한글 입력 받기
		request.setCharacterEncoding("utf-8");

		//
		response.setContentType("text/html; charset=utf-8;");

		// 브라우저에서 보낸 값을 확보
		// key에 해당하는 값이 없으면 null
		// input에 값이 없으면 ""이게 오는 것이고, null이 아님
		String key = request.getParameter("key");
		String id = request.getParameter("id");
		System.out.println("key: " + key);
		System.out.println("id: " + id);

		PrintWriter out = response.getWriter();
		out.println("key: [" + key + "]");
		out.println("<br>");
		out.println("id: [" + id + "]");
		out.println("<br>");

		String game = request.getParameter("game");

		Enumeration en = request.getParameterNames();
		while (en.hasMoreElements()) {
			String name = (String) en.nextElement();
			System.out.println("name: " + name);
			String[] values = request.getParameterValues("name");
			if (values != null) {
				for (String g : values) {
					System.out.println("values: " + g);
					out.println("values 반복: [" + g + "]<br>");
				}
			} else {
				out.println("선택한 게임이 없습니다<br>");
			}
		}
	}

}
