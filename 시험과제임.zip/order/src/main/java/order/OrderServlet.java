package order;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@WebServlet("/order")
public class OrderServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");

		String action = request.getParameter("action");
		int orderId = Integer.parseInt(request.getParameter("order_id"));
		OrderDAO dao = new OrderDAO();
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();

		if (orderId != 1) {
			String errorJson = "{\"error\":\"유효하지 않은 요청입니다 스크립트 조작을 삼가하십시오.\"}";
			response.getWriter().write(errorJson);
			return;
		}

		if ("get".equals(action)) {
			Order order = dao.getOrderById(orderId);
			String orderJson = gson.toJson(order);
			response.getWriter().write(orderJson);
		} else if ("update".equals(action)) {
			String content = request.getParameter("content");
			boolean isSuccess = dao.updateOrderContent(orderId, content);
			response.getWriter().write("{\"success\":" + isSuccess + "}");
		} else {
			String errorJson = "{\"error\":\"알 수 없는 요청입니다.\"}";
			response.getWriter().write(errorJson);
		}
	}
}