package order;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class OrderDAO {
	
	private Connection con;
    private PreparedStatement ps;
    private ResultSet rs;

    public OrderDAO() {
        connDB();
    }

	private void connDB() {

		try {
			Context ctx = new InitialContext();
			DataSource dataFactory = (DataSource) ctx.lookup("java:/comp/env/jdbc/oracle");
			this.con = dataFactory.getConnection();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public Order getOrderById(int orderId) {
        Order order = null;
        try {
            String query = "SELECT order_id, content, modified_date FROM orderlist WHERE order_id = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, orderId);
            rs = ps.executeQuery();

            if (rs.next()) {
                order = new Order();
                order.setOrderId(rs.getInt("order_id"));
                order.setContent(rs.getString("content"));
                order.setModifiedDate(rs.getDate("modified_date"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (ps != null) ps.close(); } catch (Exception e) {}
            try { if (con != null) con.close(); } catch (Exception e) {}
        }
        return order;
    }
	
	public boolean updateOrderContent(int orderId, String content) {
        connDB(); // DB 연결

        String sql = "UPDATE orderlist SET content = ?, modified_date = SYSDATE WHERE order_id = ?";
        try (PreparedStatement pstmt = con.prepareStatement(sql)) {
            pstmt.setString(1, content);
            pstmt.setInt(2, orderId);
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0; // 수정된 행이 있으면 true, 없으면 false 반환
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            try { if (con != null) con.close(); } catch (Exception e) { e.printStackTrace(); }
        }
    }
	
}
