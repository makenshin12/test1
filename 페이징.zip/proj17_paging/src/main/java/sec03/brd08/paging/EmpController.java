package sec03.brd08.paging;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EmpController
 */
@WebServlet("/emp")
public class EmpController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// controller :
		// 요청에 따라서 service 호출
		// service의 결과물에 어떤 view로 보낼지 결정
		
		// service :
		// 계산 등의 일을 담당
		// dao 호출 
		
		// dao :
		// DB 호출
		
		// jsp :
		// view
		int pageNum = 1;
		int countPerPage = 10;
		
		try {
			// 페이지 번호
			String tmp_pageNum = request.getParameter("pageNum");
			if(tmp_pageNum != null) {
				pageNum = Integer.parseInt(tmp_pageNum);
			}
			// 페이지당 보여줄 행의 갯수
			String tmp_countPerPage = request.getParameter("countPerPage");
			if(tmp_countPerPage != null) {
				countPerPage = Integer.parseInt(tmp_countPerPage);
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		
		
		EmpService empService = new EmpService();
		
		// 전체 행 수
		int totalCount = empService.getTotalEmp();
		
		List<EmpDTO> list = empService.listEmp(pageNum, countPerPage);
		
		request.setAttribute("pageNum", pageNum);
		request.setAttribute("countPerPage", countPerPage);
		request.setAttribute("totalCount", totalCount);
		request.setAttribute("list", list);
		request.getRequestDispatcher("emp.jsp").forward(request, response);
		
	}


}
