package kr.or.human.emp.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.human.emp.dao.EmpDAO;
import kr.or.human.emp.dto.EmpDTO;
import kr.or.human.emp.view.EmpView;

@WebServlet("/emp")
public class EmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {
			// 요청 및 응답 객체의 문자 인코딩 설정
			request.setCharacterEncoding("utf-8");
			response.setContentType("text/html; charset=utf-8;");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("예외");
		}
		// 전달받은 값(parameter) 확보
		// deptno
		String ename = request.getParameter("ename");
		String strDeptno = request.getParameter("deptno");
		int deptno = -1;
		try {
			deptno = Integer.parseInt(strDeptno);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("예외");
		}

		// DB 담당에게 전달 후
		// DTO 객체에 사용자 입력 값 설정
		EmpDTO empDTO = new EmpDTO();
		empDTO.setEname(ename);
		empDTO.setDeptno(deptno);

		// DAO 데이터베이스 조회
		EmpDAO empDAO = new EmpDAO();
		List list = empDAO.selectEmp(empDTO);
		System.out.println(list);
		
		// 조회 결과를 empView 객체로 처리
		EmpView empView = new EmpView();
		StringBuffer sb = empView.drawList(list, response);

		response.getWriter().println(sb);
		// view 담당에게 전달
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 한글 깨짐 방지
		try {
			request.setCharacterEncoding("utf-8");
			response.setContentType("text/html; charset=utf-8;");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("예외");
		}

		// empno
		String ename = request.getParameter("ename");
		String strEmpno = request.getParameter("empno");
		int empno = -1;
		try {
			empno = Integer.parseInt(strEmpno);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("예외");
		}

		// DTO 객체에 사용자 입력 값 설정
		EmpDTO empDTO = new EmpDTO();
		empDTO.setEname(ename);
		empDTO.setEmpno(empno);

		// DAO를 통해 데이터 업데이트 요청
		EmpDAO empDAO = new EmpDAO();
		int result = empDAO.updateEmp2(empDTO);
		System.out.println("업데이트 결과:" + result);

		response.sendRedirect("emp");
	}

	// empty
	protected void doPut(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	// empty
	protected void doDelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

}