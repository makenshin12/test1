package kr.or.human.emp.view;

import java.sql.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import kr.or.human.emp.dto.EmpDTO;

public class EmpView {
	public StringBuffer drawList(List list, HttpServletResponse response) {
		StringBuffer sb = new StringBuffer();

		// empno값 불러오기
		sb.append("<table border = 1>");

		for (int i = 0; i < list.size(); i++) {
			
			EmpDTO dto = (EmpDTO)list.get(i);
			int empno = dto.getEmpno();
			String ename = dto.getEname();
			Date hiredate = dto.getHiredate();
			
			sb.append("	<tr>");
			sb.append("		<td>");
			sb.append(empno);
			sb.append("		</td>");
			sb.append("		<td>");
			sb.append(ename);
			sb.append("		</td>");
			sb.append("		<td>");
			sb.append(hiredate);
			sb.append("		</td>");
			sb.append("	</tr>");
		} // for 닫음
		
		sb.append("</table>");

		return sb;
		
	
	} // StringBuffer() 닫음
	
} // Class 닫음
